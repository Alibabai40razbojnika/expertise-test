package com.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryException;
import com.google.cloud.bigquery.BigQueryOptions;
import com.google.cloud.bigquery.CsvOptions;
import com.google.cloud.bigquery.ExternalTableDefinition;
import com.google.cloud.bigquery.Field;
import com.google.cloud.bigquery.JobException;
import com.google.cloud.bigquery.QueryJobConfiguration;
import com.google.cloud.bigquery.Schema;
import com.google.cloud.bigquery.StandardSQLTypeName;
import com.google.cloud.functions.BackgroundFunction;
import com.google.cloud.functions.Context;
import com.example.Example.GCSEvent;
import com.example.Example.ExampleProperties;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Example implements BackgroundFunction<GCSEvent> {

    private static final Logger LOGGER = Logger.getLogger(Example.class.getName());

    private static final String PROPERTIES_PATH = "/properties.json";

    private ExampleProperties properties = null;

    private BigQuery bigQuery = null;

    @Override
    public void accept(GCSEvent event, Context context) {
        runExternalTableQuery(event.name);
    }

    private void runExternalTableQuery(String fileName) {
        LOGGER.log(Level.INFO, "Query execution started on " + fileName + ".");
        try {
            CsvOptions csvOptions = CsvOptions.newBuilder().setSkipLeadingRows(1).setFieldDelimiter(getProperties().getFieldDelimiter()).build();

            ExternalTableDefinition externalTableDefinition
                    = ExternalTableDefinition.newBuilder("gs://" + getProperties().getBucketName() + "/" + fileName,
                            csvOptions).setSchema(mainTableSchema()).build();

            QueryJobConfiguration queryConfig
                    = QueryJobConfiguration.newBuilder(mergeTableQuery())
                            .addTableDefinition(getProperties().getMainTableName(), externalTableDefinition)
                            .build();

            getBigQuery().query(queryConfig);

            LOGGER.log(Level.INFO, "Query on file " + fileName + " was executed!");
        } catch (BigQueryException | NullPointerException | InterruptedException | JobException ex) {
            LOGGER.log(Level.WARNING, "Query on file " + fileName + " was not executed!", ex);
        }
    }

    private String getFullFormatedTableName() {
        return "`" + getProperties().getProjectId() + "." + getProperties().getDatasetName() + "." + getProperties().getFormatedTableName() + "`";
    }

    private Schema mainTableSchema() {
        Schema schema
                = Schema.of(
                        Field.of("date_time", StandardSQLTypeName.STRING),
                        Field.of("serial_number", StandardSQLTypeName.STRING),
                        Field.of("gps_longitude", StandardSQLTypeName.FLOAT64),
                        Field.of("gps_latitude", StandardSQLTypeName.FLOAT64),
                        Field.of("total_working_hours_counter_h", StandardSQLTypeName.FLOAT64),
                        Field.of("engine_speed_rpm", StandardSQLTypeName.INT64),
                        Field.of("engine_load", StandardSQLTypeName.INT64),
                        Field.of("fuel_consumption_l_h", StandardSQLTypeName.FLOAT64),
                        Field.of("ground_speed_gearbox_km_h", StandardSQLTypeName.FLOAT64),
                        Field.of("ground_speed_radar_km_h", StandardSQLTypeName.FLOAT64),
                        Field.of("coolant_temperature_c", StandardSQLTypeName.INT64),
                        Field.of("speed_front_pto_rpm", StandardSQLTypeName.INT64),
                        Field.of("speed_rear_pto_rpm", StandardSQLTypeName.INT64),
                        Field.of("current_gear_shift", StandardSQLTypeName.STRING),
                        Field.of("ambient_temperature_c", StandardSQLTypeName.STRING),
                        Field.of("parking_brake_status", StandardSQLTypeName.INT64),
                        Field.of("transverse_differential_lock_status", StandardSQLTypeName.INT64),
                        Field.of("all_wheel_drive_status", StandardSQLTypeName.STRING),
                        Field.of("actual_status_of_creeper", StandardSQLTypeName.STRING));
        return schema;
    }

    private ExampleProperties getProperties() {
        if (null == properties) {
            ObjectMapper mapper = new ObjectMapper();
            InputStream is = getClass().getResourceAsStream(PROPERTIES_PATH);
            try {
                properties = mapper.readValue(is, ExampleProperties.class);
                LOGGER.log(Level.INFO, "ExampleProperties setup finished.");
            } catch (IOException ex) {
                LOGGER.log(Level.WARNING, "IOException: File on " + PROPERTIES_PATH, ex);
            }
        }
        return properties;
    }

    public BigQuery getBigQuery() {
        if (null == bigQuery) {
            GoogleCredentials credentials;
            try (InputStream inputStream = getClass().getResourceAsStream(getProperties().getCredentialsPath())) {
                credentials = ServiceAccountCredentials.fromStream(inputStream);
                bigQuery = BigQueryOptions.newBuilder()
                        .setCredentials(credentials)
                        .setProjectId(getProperties().getProjectId())
                        .setLocation(getProperties().getLocation())
                        .build()
                        .getService();
                LOGGER.log(Level.INFO, "BigQuery setup finished.");
            } catch (FileNotFoundException ex) {
                LOGGER.log(Level.WARNING, "FileNotFoundException: " + getProperties().getCredentialsPath(), ex);
            } catch (IOException ex) {
                LOGGER.log(Level.WARNING, "IOException", ex);
            }
        }
        return bigQuery;
    }

    private String mergeTableQuery() {
        StringBuilder mergeTableQueryBuilder = new StringBuilder();
        mergeTableQueryBuilder
                .append("merge ").append(getFullFormatedTableName()).append(" inTable ")
                .append("using ").append(externalTableQuery()).append(" exTable ")
                .append("on ")
                .append("inTable.serial_number = exTable.serialNumber and ")
                .append("inTable.date = exTable.date ")
                .append("when matched then ")
                .append("update set ")
                .append("inTable.total_working_hours = exTable.totalWorkingHours, ")
                .append("inTable.working_hours = exTable.workingHours, ")
                .append("inTable.min_revolutions = exTable.minRevolutions, ")
                .append("inTable.avg_revolutions = exTable.avgRevolutions, ")
                .append("inTable.max_revolutions = exTable.maxRevolutions, ")
                .append("inTable.min_engine_load = exTable.minEngineLoad, ")
                .append("inTable.avg_engine_load = exTable.avgEngineLoad, ")
                .append("inTable.max_engine_load = exTable.maxEngineLoad, ")
                .append("inTable.min_fuel_consumption = exTable.minFuelConsumption, ")
                .append("inTable.avg_fuel_consumption = exTable.avgFuelConsumption, ")
                .append("inTable.max_fuel_consumption = exTable.maxFuelConsumption, ")
                .append("inTable.coordinate_list = exTable.coordinateList ")
                .append("when not matched then ")
                .append("insert ")
                .append("values ")
                .append("(exTable.serialNumber, exTable.date, exTable.totalWorkingHours, exTable.workingHours, exTable.minRevolutions, exTable.avgRevolutions, exTable.maxRevolutions, exTable.minEngineLoad, exTable.avgEngineLoad, exTable.maxEngineLoad, exTable.minFuelConsumption, exTable.avgFuelConsumption, exTable.maxFuelConsumption, exTable.coordinateList)");
        return mergeTableQueryBuilder.toString();
    }

    private String externalTableQuery() {

        StringBuilder externalTableQueryBuilder = new StringBuilder();
        externalTableQueryBuilder.append("(select ")
                .append("serial_number as serialNumber, ")
                .append("date(parse_datetime('%b %e, %Y %l:%M:%S %p', date_time)) as date, ")
                .append("max(total_working_hours_counter_h) as totalWorkingHours, ")
                .append("max(total_working_hours_counter_h) - min(total_working_hours_counter_h) as workingHours, ")
                .append("min(engine_speed_rpm) as minRevolutions, ")
                .append("avg(engine_speed_rpm) as avgRevolutions, ")
                .append("max(engine_speed_rpm) as maxRevolutions, ")
                .append("min(engine_load) as minEngineLoad, ")
                .append("avg(engine_load) as avgEngineLoad, ")
                .append("max(engine_load) as maxEngineLoad, ")
                .append("min(fuel_consumption_l_h) as minFuelConsumption, ")
                .append("avg(fuel_consumption_l_h) as avgFuelConsumption, ")
                .append("max(fuel_consumption_l_h) as maxFuelConsumption, ")
                .append("array_agg(struct(gps_longitude, gps_latitude)) as coordinateList ")
                .append("from ").append(getProperties().getMainTableName()).append(" ")
                .append("group by date, serialNumber)");

        return externalTableQueryBuilder.toString();
    }

    public static class GCSEvent {

        String bucket;
        String name;
        String metageneration;
    }

    public static class ExampleProperties {

        private String projectId;
        private String datasetName;
        private String mainTableName;
        private String formatedTableName;
        private String fieldDelimiter;
        private String credentialsPath;
        private String bucketName;
        private String location;

        public String getProjectId() {
            return projectId;
        }

        public void setProjectId(String projectId) {
            this.projectId = projectId;
        }

        public String getDatasetName() {
            return datasetName;
        }

        public void setDatasetName(String datasetName) {
            this.datasetName = datasetName;
        }

        public String getMainTableName() {
            return mainTableName;
        }

        public void setMainTableName(String mainTableName) {
            this.mainTableName = mainTableName;
        }

        public String getFormatedTableName() {
            return formatedTableName;
        }

        public void setFormatedTableName(String formatedTableName) {
            this.formatedTableName = formatedTableName;
        }

        public String getFieldDelimiter() {
            return fieldDelimiter;
        }

        public void setFieldDelimiter(String fieldDelimiter) {
            this.fieldDelimiter = fieldDelimiter;
        }

        public String getCredentialsPath() {
            return credentialsPath;
        }

        public void setCredentialsPath(String credentialsPath) {
            this.credentialsPath = credentialsPath;
        }

        public String getBucketName() {
            return bucketName;
        }

        public void setBucketName(String bucketName) {
            this.bucketName = bucketName;
        }

        public String getLocation() {
            return location;
        }

        public void setLocation(String location) {
            this.location = location;
        }

        @Override
        public String toString() {
            return "ExampleProperties{" + "projectId=" + projectId + ", datasetName=" + datasetName + ", mainTableName=" + mainTableName + ", formatedTableName=" + formatedTableName + ", fieldDelimiter=" + fieldDelimiter + ", credentialsPath=" + credentialsPath + ", bucketName=" + bucketName + ", location=" + location + '}';
        }
    }
}
